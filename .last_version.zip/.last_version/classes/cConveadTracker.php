<?php

class cConveadTracker {

    static $MODULE_ID = "platina.tracker";

    static function getVisitorInfo($id) {
        if ($usr = CUser::GetByID($id)) {
            $user = $usr->Fetch();
            $visitor_info = array();
            $user["NAME"] && $visitor_info["first_name"] = $user["NAME"];
            $user["LAST_NAME"] && $visitor_info["last_name"] = $user["LAST_NAME"];
            $user["EMAIL"] && $visitor_info["email"] = $user["EMAIL"];
            $user["PERSONAL_PHONE"] && $visitor_info["phone"] = $user["PERSONAL_PHONE"];
            $user["PERSONAL_BIRTHDAY"] && $visitor_info["date_of_birth"] = date('Y-m-d', $user["PERSONAL_BIRTHDAY"]);
            $user["PERSONAL_GENDER"] && $visitor_info["gender"] = ($user["PERSONAL_GENDER"] == "M" ? "male" : "femail");
            return $visitor_info;
        } else {
            return false;
        }
    }

    static function getUid() {
        return substr(md5($_SESSION["SESS_SESSION_ID"]), 1, 16);
    }
    
    static function productView($arResult, $user_id = false) { 
        $api_key = COption::GetOptionString(self::$MODULE_ID, "tracker_code", '');
        if(!$api_key)
            return;
        
        global $APPLICATION;
        $guest_uid = self::getUid();
        $visitor_uid = false;
        $visitor_info = false;
        if ($user_id && $visitor_info = self::getVisitorInfo($user_id)) {
            $visitor_uid = (int)$user_id;
        }

        $tracker = new ConveadTracker($api_key, $guest_uid, $visitor_uid, $visitor_info, false, SITE_SERVER_NAME);

        $product_id = $arResult["ID"];
        $product_name = $arResult["NAME"];
        $product_url = "http://" . SITE_SERVER_NAME . $APPLICATION->GetCurPage();

        $result = $tracker->eventProductView($product_id, $product_name, $product_url);
        
        return true;
    }

    static function addToCart($arFields) {
        $api_key = COption::GetOptionString(self::$MODULE_ID, "tracker_code", '');
        if(!$api_key)
            return;
        $guest_uid = self::getUid();
        $visitor_uid = false;
        $visitor_info = false;
        if ($arFields["FUSER_ID"] && $arFields["FUSER_ID"] && $visitor_info = self::getVisitorInfo($arFields["FUSER_ID"])) {
            $visitor_uid = $arFields["FUSER_ID"];
        }

        $tracker = new ConveadTracker($api_key, $guest_uid, $visitor_uid, $visitor_info, false, SITE_SERVER_NAME);

        $product_id = $arFields["PRODUCT_ID"];
        $qnt = $arFields["QUANTITY"];
        $product_name = $arFields["NAME"];
        $product_url = "http://" . SITE_SERVER_NAME . $arFields["DETAIL_PAGE_URL"];
        $price = $arFields["PRICE"];

        $result = $tracker->eventAddToCart($product_id, $qnt, $product_name, $product_url, $price);
        
        return true;
    }

    static function removeFromCart($id) {
        $arFields = CSaleBasket::GetByID($id);
        
        $api_key = COption::GetOptionString(self::$MODULE_ID, "tracker_code", '');
        if(!$api_key)
            return;
        $guest_uid = self::getUid();
        $visitor_uid = false;
        $visitor_info = false;
        if ($arFields["FUSER_ID"] && $arFields["FUSER_ID"] && $visitor_info = self::getVisitorInfo($arFields["FUSER_ID"])) {
            $visitor_uid = $arFields["FUSER_ID"];
        }

        $tracker = new ConveadTracker($api_key, $guest_uid, $visitor_uid, $visitor_info, false, SITE_SERVER_NAME);

        $product_id = $arFields["PRODUCT_ID"];
        $qnt = $arFields["QUANTITY"];
        $product_name = $arFields["NAME"];
        $product_url = "http://" . SITE_SERVER_NAME . $arFields["DETAIL_PAGE_URL"];
        $price = $arFields["PRICE"];

        $result = $tracker->eventRemoveFromCart($product_id, $qnt);
       
        
        return true;
    }

    static function order($order_id, $arFields) {
        $api_key = COption::GetOptionString(self::$MODULE_ID, "tracker_code", '');
        if(!$api_key)
            return;
        $guest_uid = self::getUid();
        $visitor_uid = false;
        $visitor_info = false;
        if ($arFields["USER_ID"] && $arFields["USER_ID"] && $visitor_info = self::getVisitorInfo($arFields["USER_ID"])) {
            $visitor_uid = $arFields["USER_ID"];
        }
            
        $tracker = new ConveadTracker($api_key, $guest_uid, $visitor_uid, $visitor_info, false, SITE_SERVER_NAME);
        
        $items = array();
        $orders = CSaleBasket::GetList(
                        array(), array(
                    "ORDER_ID" => $order_id
                        ), false, false, array()
        );
        $i = 0;
        while ($order = $orders->Fetch()) {
            
            $item["id"] = $order["PRODUCT_ID"];
            $item["qnt"] = $order["QUANTITY"];
            $item["price"] = $order["PRICE"];
            $items[$i.""] = $item;
            $i++;
        }

        $price = $arFields["PRICE"];

        $result = $tracker->eventOrder($order_id, $price, $items);
        
        return true;
    }

    static function view() {
        $api_key = COption::GetOptionString(self::$MODULE_ID, "tracker_code", '');
        if(!$api_key)
            return;

        global $USER;
        global $APPLICATION;

        
        
        
        $guest_uid = self::getUid();
        $visitor_info = false;
        $visitor_uid = false;
        if($USER->GetID() && $USER->GetID() > 0 && $visitor_info = self::getVisitorInfo($USER->GetID())){
            $visitor_uid = $USER->GetID();
        }

        $title = $APPLICATION->GetTitle();
        $url = $APPLICATION->GetCurUri();

        $tracker = new ConveadTracker($api_key, $guest_uid, $visitor_uid, $visitor_info, false, SITE_SERVER_NAME);

        $result = $tracker->view($url, $title);
       
       
        
        return true;
    }

    static function head() {
        $api_key = COption::GetOptionString(self::$MODULE_ID, "tracker_code", '');
        if(!$api_key)
            return;

        global $USER;
        global $APPLICATION;

        
        
        $guest_uid = self::getUid();
        $visitor_info = false;
        $visitor_uid = false;
        if($USER && $USER->GetID() && $USER->GetID() > 0 && $visitor_info = self::getVisitorInfo($USER->GetID())){
            $visitor_uid = $USER->GetID();
        }

        $vi = "";
        if($visitor_info){
            foreach($visitor_info as $key=>$val){
                $vi.="\n".$key.": '".$val."',";
            }
        }

        $head = "<!-- Convead Widget -->
                    <script>
                    window.ConveadSettings = {
                        /* Use only [0-9a-z-] characters for visitor uid!*/
                        ". ($visitor_uid ? "visitor_uid: '$visitor_uid'," : "") ."
                        visitor_info: {
                            $vi
                        }, 
                        app_key: \"$api_key\"

                        /* For more information on widget configuration please see:
                           http://convead.uservoice.com/knowledgebase/articles/344831-how-to-embed-a-tracking-code-into-your-websites
                        */
                    };

                    (function(w,d,c){w[c]=w[c]||function(){(w[c].q=w[c].q||[]).push(arguments)};var ts = (+new Date()/86400000|0)*86400;var s = d.createElement('script');s.type = 'text/javascript';s.async = true;s.src = 'http://tracker.staging.convead.io/widgets/'+ts+'/widget-$api_key.js';var x = d.getElementsByTagName('script')[0];x.parentNode.insertBefore(s, x);})(window,document,'convead');
                    </script>
                    <!-- /Convead Widget -->";
        $APPLICATION->AddHeadString($head,true);
       
       
        
        return true;
    }

}
