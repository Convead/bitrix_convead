<?php
$MESS['MAKE_REDIRECT_NO'] = "Нет";
$MESS['MAKE_REDIRECT_YES'] = "Да";

$MESS['MAKE_REDIRECT'] = "Перенаправлять ли посетителя на отдельную \"thank you\" страницу";
$MESS['REDIRECT_URL'] = "Адрес \"thank you\" страницы";
$MESS['TRACKER_CODE'] = "Уникальный код трекера";
$MESS['OPTIONS_RESTORED'] = "Значения сброшены";
$MESS['OPTIONS_SAVED'] = "Значения сохранены успешно";

$MESS['ERROR_TRACKER_CODE_EMPTY'] = "Значение уникального кода трекера должно быть заполнено";
$MESS['ERROR_TRACKER_REDIRECT_URL'] = "Адрес \"thank you\" страницы должен быть заполнен";
?>