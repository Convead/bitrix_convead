<?php
$arModuleVersion = array(
    "VERSION" => "1.0.0",
    "VERSION_DATE" => "2014-10-01 15:00:00"
);
?>